﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

public class ChatController : Controller
{
    string connStr = "Server=ADMIN\\SQLEXPRESS;Database=ChatApp;Trusted_Connection=True;TrustServerCertificate=True";

    public IActionResult UserChat()
    {
        List<string> messages = new List<string>();

        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT Sender, Content FROM Messages", conn);
            var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                messages.Add(reader["Sender"] + ": " + reader["Content"]);
            }
        }

        return View(messages);
    }

    public IActionResult Host()
    {
        return UserChat();
    }

    [HttpPost]
    public IActionResult Send(string content)
    {
        string user = HttpContext.Session.GetString("user");

        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Messages VALUES (@s,@c,GETDATE())", conn);
            cmd.Parameters.AddWithValue("@s", user);
            cmd.Parameters.AddWithValue("@c", content);
            cmd.ExecuteNonQuery();
        }

        return RedirectToAction("UserChat");
    }
}