﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

public class AuthController : Controller
{
    string connStr = "Server=ADMIN\\SQLEXPRESS;Database=ChatApp;Trusted_Connection=True;TrustServerCertificate=True";

    public IActionResult Login()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Login(string username, string password)
    {
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT Role FROM Users WHERE Username=@u AND Password=@p";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@u", username);
            cmd.Parameters.AddWithValue("@p", password);

            var role = cmd.ExecuteScalar();

            if (role != null)
            {
                HttpContext.Session.SetString("user", username);

                if (role.ToString() == "host")
                    return RedirectToAction("Host", "Chat");
                else
                    return RedirectToAction("UserChat", "Chat");
            }
        }

        ViewBag.Error = "Sai tài khoản!";
        return View();
    }
}
